﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp5
{
    internal class GlobalVar
    {
        public static int memberID = 0;
        public static string str登入姓名 = "";
        public static int int權限 = 0; //會員:1, 店員:10, 店長:100, 系統管理員:1000
    }
}
