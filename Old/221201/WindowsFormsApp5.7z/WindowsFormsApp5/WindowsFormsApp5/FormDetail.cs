﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp5
{
    public partial class FormDetail : Form
    {
        public int PID = 0;
        string strDBConnectString = "";
        string image_dir = @"images\"; //圖檔目錄
        string image_name = ""; //圖檔名稱
        bool is已修改圖檔 = false;

        public FormDetail()
        {
            InitializeComponent();
        }

        private void FormDetail_Load(object sender, EventArgs e)
        {
            SqlConnectionStringBuilder scsb = new SqlConnectionStringBuilder();
            scsb.DataSource = @"."; //伺服器名稱，"@"為字串忽略特殊符號
            scsb.InitialCatalog = "mydb"; //資料庫名稱
            scsb.IntegratedSecurity = true; //Windows驗證
            strDBConnectString = scsb.ToString(); //取得資料庫連線字串

            if (PID > 0)
            {
                //修改模式
                groupBox新增.Visible = false;
                groupBox修改.Visible = true;
                顯示商品詳細資訊();
            }
            else
            {
                //新增模式
                groupBox新增.Visible = true;
                groupBox修改.Visible = false;
            }
        }

        void 顯示商品詳細資訊()
        {
            SqlConnection con = new SqlConnection(strDBConnectString);
            con.Open();
            string strSQL = "select * from products where pid =@SearchID;";
            SqlCommand cmd=new SqlCommand(strSQL, con);
            cmd.Parameters.AddWithValue("@SearchID", PID);
            SqlDataReader reader= cmd.ExecuteReader();

            int i = 0;
            while (reader.Read())
            {
                lblPID.Text = reader["pid"].ToString();
                txt商品名稱.Text= reader["pname"].ToString();
                txt商品價格.Text= reader["price"].ToString();
                txt商品描述.Text= reader["pdesc"].ToString();
                image_name = reader["pimage"].ToString();
                pictureBox商品圖檔.Image = Image.FromFile(image_dir + image_name);
                i += 1;
            }
            reader.Close();
           con.Close();
            Console.WriteLine($"查詢 {i} 筆資料.");
        }

        private void btn選取商品圖片_Click(object sender, EventArgs e)
        {
            OpenFileDialog f = new OpenFileDialog();
            f.Filter = "檔案類型 (*.jpg, *.jpeg, *.png)|*.jpeg;*.jpg;*.png"; //檔案類型過濾，"|"符號左側為描述 右側為支援的副檔名(以";"區隔)
            DialogResult R = f.ShowDialog();

            if (R == DialogResult.OK)
            {
                pictureBox商品圖檔.Image = Image.FromFile(f.FileName);
                string fileExtension = System.IO.Path.GetExtension(f.SafeFileName); //SafeFileName不包含目錄
                Random myRand = new Random();
                image_name = DateTime.Now.ToString("yyyyMMddHHmmss") + myRand.Next(1000, 10000).ToString() + fileExtension; //系統化圖檔名稱
                is已修改圖檔 = true;
                Console.WriteLine(image_name);
            }
        }

        private void btn儲存修改_Click(object sender, EventArgs e)
        {
            if ((txt商品名稱.Text != "") && (txt商品價格.Text != "") && (txt商品描述.Text != "") && (pictureBox商品圖檔.Image != null))
            {
                if (is已修改圖檔 == true)
                {
                    pictureBox商品圖檔.Image.Save(image_dir + image_name);
                    is已修改圖檔 = false;
                }

                //Insert進products
                SqlConnection con = new SqlConnection(strDBConnectString); //參數為資料庫連線字串
                con.Open();
                string strSQL = "update products set pname=@NewPname, price=@NewPrice, pdesc=@NewPDesc, pimage=@NewPimage where pid=@SearchID;";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@SearchID", PID);
                cmd.Parameters.AddWithValue("@NewPname", txt商品名稱.Text);
                int intPrice = 0;
                Int32.TryParse(txt商品價格.Text, out intPrice);
                cmd.Parameters.AddWithValue("@NewPrice", intPrice);
                cmd.Parameters.AddWithValue("@NewPDesc", txt商品描述.Text);
                cmd.Parameters.AddWithValue("@NewPimage", image_name);
                int rows = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show($"資料儲存成功, 影響{rows}筆資料");
            }
            else
            {
                MessageBox.Show("所有欄位必填 !!");
            }
        }

        private void btn清空欄位_Click(object sender, EventArgs e)
        {
            lblPID.Text = "";
            txt商品名稱.Clear();
            txt商品價格.Clear();
            txt商品描述.Clear();
            pictureBox商品圖檔.Image = null;
        }

        private void btn儲存商品_Click(object sender, EventArgs e)
        {
            if ((txt商品名稱.Text != "") && (txt商品價格.Text != "") && (txt商品描述.Text != "") && (pictureBox商品圖檔.Image != null))
            {
                if (is已修改圖檔 == true)
                {
                    pictureBox商品圖檔.Image.Save(image_dir + image_name);
                    is已修改圖檔 = false;
                }

                //Insert進products
                SqlConnection con = new SqlConnection(strDBConnectString); //參數為資料庫連線字串
                con.Open();
                string strSQL = "insert into products values (@NewPname, @NewPrice, @NewPDesc, @NewPimage);";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@NewPname", txt商品名稱.Text);
                int intPrice = 0;
                Int32.TryParse(txt商品價格.Text, out intPrice);
                cmd.Parameters.AddWithValue("@NewPrice", intPrice);
                cmd.Parameters.AddWithValue("@NewPDesc", txt商品描述.Text);
                cmd.Parameters.AddWithValue("@NewPimage", image_name);
                int rows=cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show($"資料儲存成功, 影響{rows}筆資料");
            }
            else
            {
                MessageBox.Show("所有欄位必填 !!");
            }
        }
    }
}
