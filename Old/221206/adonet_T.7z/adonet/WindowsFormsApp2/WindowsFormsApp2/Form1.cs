﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void personsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.personsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.mydbDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: 這行程式碼會將資料載入 'mydbDataSet.persons' 資料表。您可以視需要進行移動或移除。
            this.personsTableAdapter.Fill(this.mydbDataSet.persons);

            cboxFind欄位名稱.Items.Add("姓名");
            cboxFind欄位名稱.Items.Add("電話");
            cboxFind欄位名稱.Items.Add("地址");
            cboxFind欄位名稱.Items.Add("email");
            cboxFind欄位名稱.SelectedIndex = 0;

            cboxFilter欄位名稱.Items.Add("姓名");
            cboxFilter欄位名稱.Items.Add("電話");
            cboxFilter欄位名稱.Items.Add("地址");
            cboxFilter欄位名稱.Items.Add("email");
            cboxFilter欄位名稱.SelectedIndex = 3;

            顯示筆數統計();
        }

        private void btn第一筆_Click(object sender, EventArgs e)
        {
            personsBindingSource.MoveFirst();
            顯示筆數統計();
        }

        private void btn上一筆_Click(object sender, EventArgs e)
        {
            personsBindingSource.MovePrevious();
            顯示筆數統計();
        }

        private void btn下一筆_Click(object sender, EventArgs e)
        {
            personsBindingSource.MoveNext();
            顯示筆數統計();
        }

        private void btn最後一筆_Click(object sender, EventArgs e)
        {
            personsBindingSource.MoveLast();
            顯示筆數統計();
        }

        void 顯示筆數統計()
        {
            int 目前第幾筆 = personsBindingSource.Position + 1;
            int 目前總共有幾筆 = personsBindingSource.Count;

            lbl筆數資訊.Text = string.Format("第{0}筆/共{1}筆", 目前第幾筆, 目前總共有幾筆);
        }


        private void btn儲存修改_Click(object sender, EventArgs e)
        {
            Validate();
            personsBindingSource.EndEdit();
            //tableAdapterManager.UpdateAll(mydbDataSet);
            personsTableAdapter.Update(mydbDataSet.persons);
            顯示筆數統計();
            MessageBox.Show("資料儲存成功");
        }

        private void btn刪除_Click(object sender, EventArgs e)
        {
            personsBindingSource.EndEdit();
            int 目前資料索引值 = personsBindingSource.Position;
            personsBindingSource.RemoveAt(目前資料索引值);
            personsTableAdapter.Update(mydbDataSet.persons);
            顯示筆數統計();
            MessageBox.Show("資料刪除成功");
        }

        private void btn回復資料_Click(object sender, EventArgs e)
        {
            personsBindingSource.EndEdit();
            int 目前索引值 = personsBindingSource.Position;
            personsTableAdapter.Fill(mydbDataSet.persons);
            personsBindingSource.Position = 目前索引值;
            顯示筆數統計();
            MessageBox.Show("資料回復成功");

        }

        private void btn新增_Click(object sender, EventArgs e)
        {
            personsBindingSource.AddNew();
            //dtp生日.Value = DateTime.Now;
            dtp生日.Value = new DateTime(1900,1,1,0,0,0);
            chk婚姻狀態.Checked = false;
        }

        private void btn儲存_Click(object sender, EventArgs e)
        {
            Validate();
            personsBindingSource.EndEdit();
            personsTableAdapter.Update(mydbDataSet.persons);
            顯示筆數統計();
            MessageBox.Show("資料儲存成功");
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            if (txtFind關鍵字.Text != "")
            {
                string strFind = txtFind關鍵字.Text;
                string str欄位名稱 = cboxFind欄位名稱.SelectedItem.ToString();

                int indexFind = personsBindingSource.Find(str欄位名稱, strFind);

                if (indexFind >= 0)
                {  //找到了 
                    personsBindingSource.Position = indexFind;
                } else
                {  //找不到 -1
                    MessageBox.Show("查無此人");
                }

                顯示筆數統計();
            } else
            {
                MessageBox.Show("請輸入Find關鍵字");
            }
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            if (txtFilter關鍵字.Text != "")
            {
                string strFilter = txtFilter關鍵字.Text;
                string str欄位名稱 = cboxFilter欄位名稱.SelectedItem.ToString();
                personsBindingSource.Filter = $"{str欄位名稱} like '%{strFilter}%'";

                顯示筆數統計(); 
            } else
            {
                MessageBox.Show("請輸入Filter關鍵字");
            }
        }

        private void btn移除Filter_Click(object sender, EventArgs e)
        {
            personsBindingSource.RemoveFilter();
            txtFilter關鍵字.Text = "請輸入Filter關鍵字";
            MessageBox.Show("Filter條件已移除");
            顯示筆數統計();
        }

        private void listBox搜尋結果_SelectedIndexChanged(object sender, EventArgs e)
        {
            顯示筆數統計();
        }
    }
}
