﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Linq_to_集合();
        }

        void Linq_to_集合()
        {
            Console.WriteLine("------------Linq 語法 Demo------------");

            string[] 姓名集合 = { "陳大貓", "王小明", "黃小貓", "張大書", "蔡中春" };

            //IEnumerable<string> myQueryResult = from name 
            //                                    in 姓名集合 
            //                                    where name == "王小明" 
            //                                    select name; //Query Syntax;
            var myQueryResult = from name
                                in 姓名集合
                                where name == "王小明"
                                select name; //Query Syntax;
            foreach (string myName in myQueryResult)
            {
                Console.WriteLine(myName);
            }

            Console.WriteLine("--------------------------------------");

            myQueryResult = from name
                                in 姓名集合
                            where name.Contains("大")
                            select name;
            foreach (string myName in myQueryResult)
            {
                Console.WriteLine(myName);
            }
            Console.WriteLine("--------------------------------------");

            int[] Nums = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            var result = from s in Nums select s; //Query Syntax;

            foreach (int item in result)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("--------------------------------------");
            result = from s in Nums where s >= 3 select s;

            foreach (int item in result)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("--------------------------------------");
            result = from s in Nums where s >= 3 && s < 8 select s;

            foreach (int item in result)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("--------------------------------------");
            result = from s in Nums where s >= 3 orderby s descending select s;
            //ascending

            foreach (int item in result)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("--------------------------------------");
            result = Nums.Where(s => s > 3); //Method Syntax; Lambda運算式;
            foreach (int item in result)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("--------------------------------------");
            result = Nums.Where(s => s > 3 && s < 8);
            foreach (int item in result)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("--------------------------------------");
            result = Nums.Where(s => s > 3).OrderBy(s => s);//ascending;
            result = Nums.Where(s => s > 3).OrderByDescending(s => s);//descending;

            foreach (int item in result)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("--------------------------------------");

            double average = Nums.Average();
            Console.WriteLine($"集合平均:{average}");
            average = Nums.Where(s => s >= 2 & s <= 5).Average();
            Console.WriteLine($"2...5 的平均:{average}");

            Console.WriteLine("--------------------------------------");

            int count = Nums.Count();
            Console.WriteLine($"元素數量:{count}");
            count = Nums.Count(i => i % 2 == 0);
            Console.WriteLine($"偶數元素數量:{count}");
            count = Nums.Count(i => i >= 2 && i <= 7);
            Console.WriteLine($"2...7元素數量:{count}");
            count = (from i in Nums where i >= 3 && i < 9 select i).Count();
            Console.WriteLine($"3...8元素數量:{count}");

            Console.WriteLine("--------------------------------------");

            int intMax = Nums.Max();
            Console.WriteLine($"最大值:{intMax}");
            intMax = Nums.Max(i => { if (i % 2 == 0) return i; else return 0; });
            Console.WriteLine($"偶數最大值:{intMax}");
            int intMin = Nums.Min();
            Console.WriteLine($"最小值:{intMin}");
            intMin = Nums.Min(i => { if (i % 2 == 1) return i; else return Int32.MaxValue; });
            Console.WriteLine($"奇數最小值:{intMin}");
            Console.WriteLine("--------------------------------------");

            int intSum = Nums.Sum();
            Console.WriteLine($"總和:{intSum}");
            intSum = Nums.Sum(i => { if (i % 2 == 0) return i; else return 0; });
            Console.WriteLine($"偶數總和:{intSum}");
            Console.WriteLine("--------------------------------------");

            var intFirst = Nums.First(i => i % 2 == 0);
            Console.WriteLine($"偶數的第一個數{intFirst}");
            var intLast = Nums.Last(i => i % 2 == 1);
            Console.WriteLine($"奇數的最後一個數{intLast}");

            Console.WriteLine("--------------------------------------");

            var numsEven = Nums.Where(i => i % 2 == 0);
            var numsOdd = Nums.Where(i => i % 2 == 1);
            var numsCon = numsOdd.Concat(numsEven);
            foreach (var num in numsCon)
            {
                Console.WriteLine($"{num}");
            }

            Console.WriteLine("--------------------------------------");


            List<string> listStrOne = new List<string> { "張大書","陳大貓","王小明","黃小貓"};
            List<string> listStrTwo = new List<string> { "黃中村", "陳大貓", "林阿霈", "John Lee"};

            //UINION 聯集;
            var resultUnion = listStrOne.Union(listStrTwo);

            foreach(string name in resultUnion)
            {
                Console.WriteLine(name);
            }
            Console.WriteLine("--------------------------------------");

            //Intersect 交集
            var resultIntersect = listStrOne.Intersect(listStrTwo);

            foreach(string name in resultIntersect)
            {
                Console.WriteLine(name);
            }
            Console.WriteLine("--------------------------------------");
            //Except 差集
            var resultExcept = listStrOne.Except(listStrTwo);

            foreach (string name in resultExcept)
            {
                Console.WriteLine(name);
            }
            Console.WriteLine("--------------------------------------");
        }
    }
}
