﻿namespace WindowsFormsApp4
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt訂購人 = new System.Windows.Forms.TextBox();
            this.txt杯數 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl單價 = new System.Windows.Forms.Label();
            this.lbl品項總價 = new System.Windows.Forms.Label();
            this.listBox飲料品項 = new System.Windows.Forms.ListBox();
            this.cbox甜度 = new System.Windows.Forms.ComboBox();
            this.cbox冰塊 = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chk珍珠 = new System.Windows.Forms.CheckBox();
            this.chk波霸 = new System.Windows.Forms.CheckBox();
            this.chk芋圓 = new System.Windows.Forms.CheckBox();
            this.chkQQ = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radio內用 = new System.Windows.Forms.RadioButton();
            this.radio外帶 = new System.Windows.Forms.RadioButton();
            this.chk買購物袋 = new System.Windows.Forms.CheckBox();
            this.btn訂購 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(259, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(345, 47);
            this.label1.TabIndex = 0;
            this.label1.Text = "冷飲店訂購單Menu";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(12, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(187, 38);
            this.label2.TabIndex = 1;
            this.label2.Text = "訂購人(電話)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(12, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 38);
            this.label3.TabIndex = 2;
            this.label3.Text = "飲料品項";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(50, 559);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 38);
            this.label4.TabIndex = 3;
            this.label4.Text = "數量";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(222, 559);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 38);
            this.label5.TabIndex = 4;
            this.label5.Text = "單價";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(423, 559);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 38);
            this.label6.TabIndex = 5;
            this.label6.Text = "品項總價";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(451, 209);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 38);
            this.label7.TabIndex = 6;
            this.label7.Text = "甜度";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(451, 289);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 38);
            this.label8.TabIndex = 7;
            this.label8.Text = "冰塊";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(451, 376);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 38);
            this.label9.TabIndex = 8;
            this.label9.Text = "配料";
            // 
            // txt訂購人
            // 
            this.txt訂購人.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt訂購人.Location = new System.Drawing.Point(41, 97);
            this.txt訂購人.Name = "txt訂購人";
            this.txt訂購人.Size = new System.Drawing.Size(339, 47);
            this.txt訂購人.TabIndex = 9;
            // 
            // txt杯數
            // 
            this.txt杯數.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt杯數.Location = new System.Drawing.Point(18, 600);
            this.txt杯數.Name = "txt杯數";
            this.txt杯數.Size = new System.Drawing.Size(119, 47);
            this.txt杯數.TabIndex = 10;
            this.txt杯數.TextChanged += new System.EventHandler(this.txt杯數_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(143, 603);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 38);
            this.label10.TabIndex = 11;
            this.label10.Text = "杯";
            // 
            // lbl單價
            // 
            this.lbl單價.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbl單價.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl單價.Location = new System.Drawing.Point(229, 603);
            this.lbl單價.Name = "lbl單價";
            this.lbl單價.Size = new System.Drawing.Size(150, 38);
            this.lbl單價.TabIndex = 12;
            this.lbl單價.Text = "0000元";
            // 
            // lbl品項總價
            // 
            this.lbl品項總價.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl品項總價.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl品項總價.Location = new System.Drawing.Point(423, 603);
            this.lbl品項總價.Name = "lbl品項總價";
            this.lbl品項總價.Size = new System.Drawing.Size(179, 38);
            this.lbl品項總價.TabIndex = 13;
            this.lbl品項總價.Text = "000000元";
            // 
            // listBox飲料品項
            // 
            this.listBox飲料品項.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.listBox飲料品項.FormattingEnabled = true;
            this.listBox飲料品項.ItemHeight = 34;
            this.listBox飲料品項.Location = new System.Drawing.Point(18, 209);
            this.listBox飲料品項.Name = "listBox飲料品項";
            this.listBox飲料品項.Size = new System.Drawing.Size(410, 310);
            this.listBox飲料品項.TabIndex = 14;
            this.listBox飲料品項.SelectedIndexChanged += new System.EventHandler(this.listBox飲料品項_SelectedIndexChanged);
            // 
            // cbox甜度
            // 
            this.cbox甜度.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cbox甜度.FormattingEnabled = true;
            this.cbox甜度.Location = new System.Drawing.Point(534, 206);
            this.cbox甜度.Name = "cbox甜度";
            this.cbox甜度.Size = new System.Drawing.Size(229, 46);
            this.cbox甜度.TabIndex = 15;
            this.cbox甜度.SelectedIndexChanged += new System.EventHandler(this.cbox甜度_SelectedIndexChanged);
            // 
            // cbox冰塊
            // 
            this.cbox冰塊.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cbox冰塊.FormattingEnabled = true;
            this.cbox冰塊.Location = new System.Drawing.Point(534, 286);
            this.cbox冰塊.Name = "cbox冰塊";
            this.cbox冰塊.Size = new System.Drawing.Size(229, 46);
            this.cbox冰塊.TabIndex = 16;
            this.cbox冰塊.SelectedIndexChanged += new System.EventHandler(this.cbox冰塊_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox1.Controls.Add(this.chkQQ);
            this.groupBox1.Controls.Add(this.chk芋圓);
            this.groupBox1.Controls.Add(this.chk波霸);
            this.groupBox1.Controls.Add(this.chk珍珠);
            this.groupBox1.Location = new System.Drawing.Point(534, 376);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(274, 131);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "配料一種10元";
            // 
            // chk珍珠
            // 
            this.chk珍珠.AutoSize = true;
            this.chk珍珠.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.chk珍珠.Location = new System.Drawing.Point(30, 24);
            this.chk珍珠.Name = "chk珍珠";
            this.chk珍珠.Size = new System.Drawing.Size(81, 33);
            this.chk珍珠.TabIndex = 0;
            this.chk珍珠.Text = "珍珠";
            this.chk珍珠.UseVisualStyleBackColor = true;
            this.chk珍珠.CheckedChanged += new System.EventHandler(this.chk珍珠_CheckedChanged);
            // 
            // chk波霸
            // 
            this.chk波霸.AutoSize = true;
            this.chk波霸.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.chk波霸.Location = new System.Drawing.Point(136, 24);
            this.chk波霸.Name = "chk波霸";
            this.chk波霸.Size = new System.Drawing.Size(81, 33);
            this.chk波霸.TabIndex = 1;
            this.chk波霸.Text = "波霸";
            this.chk波霸.UseVisualStyleBackColor = true;
            this.chk波霸.CheckedChanged += new System.EventHandler(this.chk波霸_CheckedChanged);
            // 
            // chk芋圓
            // 
            this.chk芋圓.AutoSize = true;
            this.chk芋圓.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.chk芋圓.Location = new System.Drawing.Point(30, 72);
            this.chk芋圓.Name = "chk芋圓";
            this.chk芋圓.Size = new System.Drawing.Size(81, 33);
            this.chk芋圓.TabIndex = 2;
            this.chk芋圓.Text = "芋圓";
            this.chk芋圓.UseVisualStyleBackColor = true;
            this.chk芋圓.CheckedChanged += new System.EventHandler(this.chk芋圓_CheckedChanged);
            // 
            // chkQQ
            // 
            this.chkQQ.AutoSize = true;
            this.chkQQ.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.chkQQ.Location = new System.Drawing.Point(136, 72);
            this.chkQQ.Name = "chkQQ";
            this.chkQQ.Size = new System.Drawing.Size(73, 33);
            this.chkQQ.TabIndex = 3;
            this.chkQQ.Text = "QQ";
            this.chkQQ.UseVisualStyleBackColor = true;
            this.chkQQ.CheckedChanged += new System.EventHandler(this.chkQQ_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.radio外帶);
            this.groupBox2.Controls.Add(this.radio內用);
            this.groupBox2.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox2.Location = new System.Drawing.Point(489, 85);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(274, 87);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            // 
            // radio內用
            // 
            this.radio內用.AutoSize = true;
            this.radio內用.Location = new System.Drawing.Point(30, 33);
            this.radio內用.Name = "radio內用";
            this.radio內用.Size = new System.Drawing.Size(92, 39);
            this.radio內用.TabIndex = 0;
            this.radio內用.TabStop = true;
            this.radio內用.Text = "內用";
            this.radio內用.UseVisualStyleBackColor = true;
            this.radio內用.CheckedChanged += new System.EventHandler(this.radio內用_CheckedChanged);
            // 
            // radio外帶
            // 
            this.radio外帶.AutoSize = true;
            this.radio外帶.Location = new System.Drawing.Point(147, 33);
            this.radio外帶.Name = "radio外帶";
            this.radio外帶.Size = new System.Drawing.Size(92, 39);
            this.radio外帶.TabIndex = 1;
            this.radio外帶.TabStop = true;
            this.radio外帶.Text = "外帶";
            this.radio外帶.UseVisualStyleBackColor = true;
            this.radio外帶.CheckedChanged += new System.EventHandler(this.radio外帶_CheckedChanged);
            // 
            // chk買購物袋
            // 
            this.chk買購物袋.AutoSize = true;
            this.chk買購物袋.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.chk買購物袋.Location = new System.Drawing.Point(670, 559);
            this.chk買購物袋.Name = "chk買購物袋";
            this.chk買購物袋.Size = new System.Drawing.Size(127, 33);
            this.chk買購物袋.TabIndex = 5;
            this.chk買購物袋.Text = "買購物袋";
            this.chk買購物袋.UseVisualStyleBackColor = true;
            this.chk買購物袋.CheckedChanged += new System.EventHandler(this.chk買購物袋_CheckedChanged);
            // 
            // btn訂購
            // 
            this.btn訂購.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn訂購.Location = new System.Drawing.Point(627, 617);
            this.btn訂購.Name = "btn訂購";
            this.btn訂購.Size = new System.Drawing.Size(181, 54);
            this.btn訂購.TabIndex = 19;
            this.btn訂購.Text = "訂購";
            this.btn訂購.UseVisualStyleBackColor = true;
            this.btn訂購.Click += new System.EventHandler(this.btn訂購_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(838, 698);
            this.Controls.Add(this.btn訂購);
            this.Controls.Add(this.chk買購物袋);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cbox冰塊);
            this.Controls.Add(this.cbox甜度);
            this.Controls.Add(this.listBox飲料品項);
            this.Controls.Add(this.lbl品項總價);
            this.Controls.Add(this.lbl單價);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txt杯數);
            this.Controls.Add(this.txt訂購人);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "冷飲店訂購單";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt訂購人;
        private System.Windows.Forms.TextBox txt杯數;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbl單價;
        private System.Windows.Forms.Label lbl品項總價;
        private System.Windows.Forms.ListBox listBox飲料品項;
        private System.Windows.Forms.ComboBox cbox甜度;
        private System.Windows.Forms.ComboBox cbox冰塊;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chkQQ;
        private System.Windows.Forms.CheckBox chk芋圓;
        private System.Windows.Forms.CheckBox chk波霸;
        private System.Windows.Forms.CheckBox chk珍珠;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radio外帶;
        private System.Windows.Forms.RadioButton radio內用;
        private System.Windows.Forms.CheckBox chk買購物袋;
        private System.Windows.Forms.Button btn訂購;
    }
}

