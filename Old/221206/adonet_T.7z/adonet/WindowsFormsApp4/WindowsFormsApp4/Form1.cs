﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        SqlConnectionStringBuilder scsb;
        string strDBConnectString = "";

        List<string> list飲料品項名稱 = new List<string>();
        List<int> list飲料價格 = new List<int>();

        List<string> list甜度 = new List<string>();
        List<string> list冰塊 = new List<string>();
        List<string> list所選配料 = new List<string>();

        int 所選飲料杯數 = 0;
        int 所選飲料單價 = 0;
        int 所選飲料品項總價 = 0;
        string 所選飲料品項 = "";
        string 所選飲料甜度 = "";
        string 所選飲料冰塊 = "";
        bool is外帶 = false;
        bool is買購物袋 = false;
        string 訂購人 = "";

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            scsb = new SqlConnectionStringBuilder();
            scsb.DataSource = @"."; //伺服器名稱
            scsb.InitialCatalog = "mydb"; //資料庫名稱
            scsb.IntegratedSecurity = true; //windows驗證
            strDBConnectString = scsb.ToString();

            list飲料品項名稱.Add("麥香紅茶");
            list飲料品項名稱.Add("茉莉綠茶");
            list飲料品項名稱.Add("波霸奶茶");

            list飲料價格.Add(30);
            list飲料價格.Add(35);
            list飲料價格.Add(40);

            list甜度.Add("正常");
            list甜度.Add("半糖");
            list甜度.Add("少糖");
            list甜度.Add("無糖");

            list冰塊.Add("正常冰");
            list冰塊.Add("少冰");
            list冰塊.Add("去冰");

            for (int i = 0; i < list飲料品項名稱.Count; i += 1)
            {
                listBox飲料品項.Items.Add(list飲料品項名稱[i]);
            }

            foreach(string item in list甜度)
            {
                cbox甜度.Items.Add(item);
            }

            foreach(string item in list冰塊)
            {
                cbox冰塊.Items.Add(item);
            }

            txt杯數.Text = "1";
            所選飲料杯數 = 1;
            cbox甜度.SelectedIndex = 0;
            所選飲料甜度 = cbox甜度.SelectedItem.ToString();
            cbox冰塊.SelectedIndex = 0;
            所選飲料冰塊 = cbox冰塊.SelectedItem.ToString();
            radio內用.Checked = true;
            is外帶 = false;
            chk買購物袋.Checked = false;
            is買購物袋 = false;
        }

        void 計算品項總價()
        {
            if (所選飲料杯數 > 0) {

                所選飲料品項總價 = 所選飲料單價 * 所選飲料杯數;

                if (list所選配料.Count > 0)
                {
                    所選飲料品項總價 = 所選飲料品項總價 + list所選配料.Count * 10;
                }

                if (is買購物袋 == true)
                {
                    所選飲料品項總價 += 2;
                }

                lbl品項總價.Text = $"{所選飲料品項總價}";
            }
        }
        private void listBox飲料品項_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox飲料品項.SelectedIndex >= 0)
            {
                所選飲料品項 = list飲料品項名稱[listBox飲料品項.SelectedIndex];
                所選飲料單價 = list飲料價格[listBox飲料品項.SelectedIndex];

                lbl單價.Text = $"{所選飲料單價}";
                計算品項總價();
            }
        }

        private void txt杯數_TextChanged(object sender, EventArgs e)
        {
            if (txt杯數.Text.Length > 0)
            {
                bool is數字 = Int32.TryParse(txt杯數.Text, out 所選飲料杯數);
                if (is數字)
                {
                    計算品項總價();
                } else
                {
                    MessageBox.Show("杯數輸入錯誤");
                }
            }
        }

        private void cbox甜度_SelectedIndexChanged(object sender, EventArgs e)
        {
            所選飲料甜度 = cbox甜度.SelectedItem.ToString();
        }

        private void cbox冰塊_SelectedIndexChanged(object sender, EventArgs e)
        {
            所選飲料冰塊 = cbox冰塊.SelectedItem.ToString();
        }

        private void chk珍珠_CheckedChanged(object sender, EventArgs e)
        {
            if (chk珍珠.Checked == true) {
                list所選配料.Add("珍珠");
            } else
            {
                list所選配料.Remove("珍珠");
            }

            計算品項總價();
        }

        private void chk波霸_CheckedChanged(object sender, EventArgs e)
        {
            if (chk波霸.Checked == true)
            {
                list所選配料.Add("波霸");
            }
            else
            {
                list所選配料.Remove("波霸");
            }

            計算品項總價();
        }

        private void chk芋圓_CheckedChanged(object sender, EventArgs e)
        {
            if (chk芋圓.Checked == true)
            {
                list所選配料.Add("芋圓");
            }
            else
            {
                list所選配料.Remove("芋圓");
            }

            計算品項總價();

        }

        private void chkQQ_CheckedChanged(object sender, EventArgs e)
        {
            if (chkQQ.Checked == true)
            {
                list所選配料.Add("QQ");
            }
            else
            {
                list所選配料.Remove("QQ");
            }

            計算品項總價();

        }

        private void radio內用_CheckedChanged(object sender, EventArgs e)
        {
            is外帶 = false;
        }

        private void radio外帶_CheckedChanged(object sender, EventArgs e)
        {
            is外帶 = true;
        }

        private void chk買購物袋_CheckedChanged(object sender, EventArgs e)
        {
            is買購物袋 = chk買購物袋.Checked;

            計算品項總價();
        }

        private void btn訂購_Click(object sender, EventArgs e)
        {
            if ((txt訂購人.Text != "") && (所選飲料杯數 > 0))
            {
                訂購人 = txt訂購人.Text;

                SqlConnection con = new SqlConnection(strDBConnectString);
                con.Open();
                string strSQL = "insert into orderlist values(@NewProductName,@NewPrice,@NewTotalPrice,@NewCups,@NewSugar,@NewIce,@NewCustomerName,@NewToGo,@NewBuyBag,@NewTopping)";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@NewProductName", 所選飲料品項);
                cmd.Parameters.AddWithValue("@NewPrice", 所選飲料單價);
                cmd.Parameters.AddWithValue("@NewTotalPrice", 所選飲料品項總價);
                cmd.Parameters.AddWithValue("@NewCups", 所選飲料杯數);
                cmd.Parameters.AddWithValue("@NewSugar", 所選飲料甜度);
                cmd.Parameters.AddWithValue("@NewIce", 所選飲料冰塊);
                cmd.Parameters.AddWithValue("@NewCustomerName",訂購人);
                cmd.Parameters.AddWithValue("@NewToGo", is外帶);
                cmd.Parameters.AddWithValue("@NewBuyBag", is買購物袋);
                string str配料集合 = "";
                foreach (string item in list所選配料)
                {
                    str配料集合 = str配料集合 + "," + item;
                }
                cmd.Parameters.AddWithValue("@NewTopping", str配料集合);

                int rows = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show($"訂購成功, 共{rows}筆 !");
            }
            else
            {
                MessageBox.Show("訂購人必填, 至少購買一杯 !");
            }
        }
    }
}
