﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class FormLogin : Form
    {
        bool is認證成功 = false;

        public FormLogin()
        {
            InitializeComponent();
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {

        }

        private void btn登入_Click(object sender, EventArgs e)
        {
            if ((txt帳號.Text != "") && (txt密碼.Text != ""))
            {
                string str帳號 = txt帳號.Text;
                string str密碼 = txt密碼.Text;

                // select * from persons where 電話 = str帳號 and 密碼 = str密碼;
                // if (reader.Read()) { is認證成功 = true };
                is認證成功 = true;

                if (is認證成功)
                {
                    MessageBox.Show("登入成功");
                    GlobalVar.memberID = 3; //reader["id"]
                    GlobalVar.int權限 = 1; //reader["權限"]
                    GlobalVar.str登入姓名 = "張大書"; //reader["姓名"]
                    Close();
                } else
                {
                    MessageBox.Show("登入失敗");
                }
            }
            else
            {
                MessageBox.Show("請輸入帳號密碼");
            }

        }

        private void FormLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (is認證成功)
            {
                e.Cancel = false;
            } else
            {
                e.Cancel = true;
            }
        }
    }
}
