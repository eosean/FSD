﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        string strMyDBConnectionString = "";
        List<string> listPname = new List<string>();
        List<int> listPrice = new List<int>();
        List<int> listPID = new List<int>();
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FormLogin myLoginForm = new FormLogin();
            myLoginForm.ShowDialog();

            SqlConnectionStringBuilder scsb = new SqlConnectionStringBuilder();
            scsb.DataSource = @".";
            scsb.InitialCatalog = "mydb";
            scsb.IntegratedSecurity = true;
            strMyDBConnectionString = scsb.ToString();

            讀取資料庫();
            展示listView商品圖片模式();

            lblLoginInfo.Text = $"ID:{GlobalVar.memberID} {GlobalVar.str登入姓名} 權限:{GlobalVar.int權限}";
        }

        void 讀取資料庫()
        {
            SqlConnection con = new SqlConnection(strMyDBConnectionString);
            con.Open();
            string strSQL = "select * from products;";
            SqlCommand cmd = new SqlCommand(strSQL, con);
            SqlDataReader reader = cmd.ExecuteReader();

            string image_dir = @"images\"; //圖檔目錄
            string image_name = ""; //圖檔名稱
            int i = 0;

            while (reader.Read())
            {
                listPID.Add((int)reader["pid"]);
                listPname.Add(reader["pname"].ToString());
                listPrice.Add((int)reader["price"]);
                image_name = reader["pimage"].ToString();
                Image myProductImage = Image.FromFile(image_dir + image_name);
                imageList產品圖檔.Images.Add(myProductImage);
                i += 1;
            }
            Console.WriteLine($"讀取{i}筆資料");
            reader.Close();
            con.Close();
        }

        private void btn圖片模式_Click(object sender, EventArgs e)
        {
            展示listView商品圖片模式();
        }

        void 展示listView商品圖片模式()
        {
            listView商品展示.Clear();
            listView商品展示.View = View.LargeIcon; //LargeIcon, SmallIcon, List, Tile
            imageList產品圖檔.ImageSize = new Size(120,120);
            listView商品展示.LargeImageList = imageList產品圖檔; //LargeIcon, Tile
            listView商品展示.SmallImageList = imageList產品圖檔; //SmallIcon, List

            for (int i = 0; i < imageList產品圖檔.Images.Count; i += 1)
            {
                ListViewItem item = new ListViewItem();
                item.ImageIndex = i;
                item.Font = new Font("微軟正黑體", 14, FontStyle.Regular);
                item.Text = listPname[i] + " " + listPrice[i] + "元";
                item.Tag = listPID[i];
                listView商品展示.Items.Add(item);
            }
        }
        private void btn列表模式_Click(object sender, EventArgs e)
        {
            展示listView商品列表模式();
        }

        void 展示listView商品列表模式()
        {
            listView商品展示.Clear();
            listView商品展示.LargeImageList = null;
            listView商品展示.SmallImageList= null;
            listView商品展示.View = View.Details;
            listView商品展示.Columns.Add("PID", 100);
            listView商品展示.Columns.Add("商品名稱", 200);
            listView商品展示.Columns.Add("商品價格", 80);
            listView商品展示.FullRowSelect = true;
            listView商品展示.GridLines = true;

            for (int i = 0; i < listPID.Count; i += 1)
            {
                ListViewItem item = new ListViewItem();
                listView商品展示.Font = new Font("微軟正黑體", 12, FontStyle.Regular);
                item.Text = listPID[i].ToString();
                item.SubItems.Add(listPname[i]);
                item.SubItems.Add(listPrice[i].ToString());
                item.Tag = listPID[i];

                listView商品展示.Items.Add(item);
            }
        }

        private void btn新增商品_Click(object sender, EventArgs e)
        {
            FormDetail myFormDetail = new FormDetail();
            myFormDetail.ShowDialog();
        }

        private void btn重新載入_Click(object sender, EventArgs e)
        {
            listPID.Clear();
            listPname.Clear();
            listPrice.Clear();
            imageList產品圖檔.Images.Clear();
            讀取資料庫();

            if (listView商品展示.View == View.Details) {

                展示listView商品列表模式();
            } else
            {
                展示listView商品圖片模式();
            }
        }

        private void listView商品展示_ItemActivate(object sender, EventArgs e)
        {
            FormDetail myFormDetail = new FormDetail();
            myFormDetail.PID = (int)listView商品展示.SelectedItems[0].Tag;
            myFormDetail.ShowDialog();
        }
    }
}
