﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace WindowsFormsApp8
{
    public partial class Form1 : Form
    {
        string stringConnect = ConfigurationManager.ConnectionStrings["WindowsFormsApp8.Properties.Settings.mydbConnectionString"].ToString();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            mydbDataClassesDataContext mydb = new mydbDataClassesDataContext(stringConnect);

            var result = from s in mydb.persons select s;
            result = from s in mydb.persons where s.點數 > 1000 select s;
            result = from s in mydb.persons where s.姓名 == "陳大貓" select s; //陳大貓
            result = from s in mydb.persons where s.姓名.Contains("大") select s; //含有大字;
            result = from s in mydb.persons where s.姓名.EndsWith("貓") select s;
            result = from s in mydb.persons where s.姓名.StartsWith("王") select s;
            result = mydb.persons.Where(s => s.地址.Contains("台南"));//住台南的會員
            result = mydb.persons.Where(s => s.婚姻狀態 == false).OrderBy(s => s.點數);
            DateTime startDate = new DateTime(1970,1,1,0,0,0);
            DateTime endDate = new DateTime(1985,12,31,0,0,0);
            result = mydb.persons.Where(s => s.生日 >= startDate && s.生日 <= endDate);

            foreach (var member in result)
            {
                Console.WriteLine($"{member.id} {member.姓名} {member.電話} {member.地址} {member.email} {member.生日} {member.婚姻狀態} {member.點數}");
            }


        }

        private void btnInsert_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

        }
    }
}
