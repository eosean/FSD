﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        SqlConnectionStringBuilder scsb;
        string strDBConnectString = "";
        List<int> SearchIDs = new List<int>(); //進階搜尋結果
        int int搜尋婚姻狀態 = 0; //0:全部, 1:已婚, 2:單身

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            scsb = new SqlConnectionStringBuilder();
            scsb.DataSource = @"."; //伺服器名稱
            scsb.InitialCatalog = "mydb"; //資料庫名稱
            scsb.IntegratedSecurity = true; //windows驗證
            strDBConnectString = scsb.ToString();

            cbox欄位名稱.Items.Add("姓名");
            cbox欄位名稱.Items.Add("電話");
            cbox欄位名稱.Items.Add("地址");
            cbox欄位名稱.Items.Add("email");
            cbox欄位名稱.SelectedIndex = 0;

            radio全部.Checked = true;
            int搜尋婚姻狀態 = 0; //0:全部, 1:已婚, 2:單身

            產生會員資料列表();
        }

        private void btn資料筆數_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(strDBConnectString);
            con.Open();
            string strSQL = "select * from persons";
            SqlCommand cmd = new SqlCommand(strSQL, con);
            SqlDataReader reader = cmd.ExecuteReader();

            string strMsg = "";
            int count = 0;

            while (reader.Read() == true)
            {
                int id = (int)reader["id"];
                string 姓名 = reader["姓名"].ToString();
                string 電話 = reader["電話"].ToString();
                string email = reader["email"].ToString();

                strMsg += $"{id} {姓名} {電話} {email} \n";
                count += 1;
            }

            strMsg += "資料筆數:" + count;
            reader.Close();
            con.Close();
            MessageBox.Show(strMsg);
        }

        private void btn資料搜尋_Click(object sender, EventArgs e)
        {
            if (txt姓名.Text != "")
            {
                SqlConnection con = new SqlConnection(strDBConnectString);
                con.Open();
                string strSQL = "select * from persons where 姓名 like @SearchName;";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@SearchName", "%" + txt姓名.Text + "%");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read() == true)
                {
                    lblID.Text = reader["id"].ToString();
                    txt姓名.Text = reader["姓名"].ToString();
                    txt電話.Text = reader["電話"].ToString();
                    txt地址.Text = reader["地址"].ToString();
                    txtEmail.Text = reader["email"].ToString();
                    txt會員點數.Text = reader["點數"].ToString();
                    dtp生日.Value = Convert.ToDateTime(reader["生日"]);
                    chk婚姻狀態.Checked = Convert.ToBoolean(reader["婚姻狀態"]);
                } else
                {
                    MessageBox.Show("查無此人");
                    清空欄位();
                }
                reader.Close();
                con.Close();
            } else
            {
                MessageBox.Show("請輸入姓名搜尋關鍵字");
            }
        }

        void 清空欄位()
        {
            lblID.Text = "";
            txt姓名.Clear();
            txt電話.Clear();
            txtEmail.Clear();
            txt地址.Clear();
            txt會員點數.Clear();
            dtp生日.Value = DateTime.Now;
            chk婚姻狀態.Checked = false;
        }


        private void btn資料修改_Click(object sender, EventArgs e)
        {
            int intID = 0;
            Int32.TryParse(lblID.Text, out intID);

            if ((intID > 0) && (txt姓名.Text !="") && (txt電話.Text != ""))
            {
                SqlConnection con = new SqlConnection(strDBConnectString);
                con.Open();
                string strSQL = "update persons set 姓名=@NewName, 電話=@NewPhone, 地址=@NewAddress, email=@NewEmail, 生日=@NewBirth, 婚姻狀態=@NewMarriage, 點數=@NewPoints where id = @SearchID;";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@NewName", txt姓名.Text);
                cmd.Parameters.AddWithValue("@NewPhone", txt電話.Text);
                cmd.Parameters.AddWithValue("@NewAddress",txt地址.Text );
                cmd.Parameters.AddWithValue("@NewEmail", txtEmail.Text);
                cmd.Parameters.AddWithValue("@NewBirth", dtp生日.Value);
                cmd.Parameters.AddWithValue("@NewMarriage", chk婚姻狀態.Checked);
                int intPoints = 0;
                Int32.TryParse(txt會員點數.Text, out intPoints);
                cmd.Parameters.AddWithValue("@NewPoints", intPoints);
                cmd.Parameters.AddWithValue("@SearchID", intID);

                int rows = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show($"({rows}個資料列受到影響)");
            }
        }

        private void btn新增資料_Click(object sender, EventArgs e)
        {
            if ((txt姓名.Text != "") && (txt電話.Text != ""))
            {
                SqlConnection con = new SqlConnection(strDBConnectString);
                con.Open();
                string strSQL = "insert into persons values (@NewName,@NewPhone,@NewAddress,@NewEmail,@NewBirth,@NewMarriage,@NewPoints);";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@NewName", txt姓名.Text);
                cmd.Parameters.AddWithValue("@NewPhone", txt電話.Text);
                cmd.Parameters.AddWithValue("@NewAddress", txt地址.Text);
                cmd.Parameters.AddWithValue("@NewEmail", txtEmail.Text);
                cmd.Parameters.AddWithValue("@NewBirth", dtp生日.Value);
                cmd.Parameters.AddWithValue("@NewMarriage", chk婚姻狀態.Checked);
                int intPoints = 0;
                Int32.TryParse(txt會員點數.Text, out intPoints);
                cmd.Parameters.AddWithValue("@NewPoints", intPoints);

                int rows = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show($"({rows}個資料列受到影響)");
            }
        }

        private void btn刪除資料_Click(object sender, EventArgs e)
        {
            int intID = 0;
            Int32.TryParse(lblID.Text, out intID);

            if (intID > 0)
            {
                SqlConnection con = new SqlConnection(strDBConnectString);
                con.Open();
                string strSQL = "delete from persons where id = @DeleteID;";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@DeleteID", intID);

                int rows = cmd.ExecuteNonQuery();
                con.Close();
                清空欄位();
                MessageBox.Show($"({rows}個資料列受到影響)");
            }
        }

        private void btn清空欄位_Click(object sender, EventArgs e)
        {
            清空欄位();
        }

        private void btn搜尋_Click(object sender, EventArgs e)
        {
            //進階搜尋
            listbox搜尋結果.Items.Clear();
            SearchIDs.Clear();
            string 欄位名稱 = cbox欄位名稱.SelectedItem.ToString();
            string sql婚姻狀態查詢語法 = "";

            if (int搜尋婚姻狀態 == 0)
            {
                sql婚姻狀態查詢語法 = "";
            } else if (int搜尋婚姻狀態 == 1)
            {
                sql婚姻狀態查詢語法 = "and 婚姻狀態 = 1";    
            } else if (int搜尋婚姻狀態 == 2)
            {
                sql婚姻狀態查詢語法 = "and 婚姻狀態 = 0";
            }

            if (txt欄位關鍵字.Text != "")
            {
                SqlConnection con = new SqlConnection(strDBConnectString);
                con.Open();
                string strSQL = "select * from persons where " + 欄位名稱 + " like @SearchKeyword and 生日 <= @BirthEnd and 生日 >= @BirthStart " + sql婚姻狀態查詢語法;
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@SearchKeyword", "%" + txt欄位關鍵字.Text + "%");
                cmd.Parameters.AddWithValue("@BirthEnd", dtp結束時間.Value);
                cmd.Parameters.AddWithValue("@BirthStart", dtp開始時間.Value);
                SqlDataReader reader = cmd.ExecuteReader();

                int count = 0;
                while (reader.Read())
                {
                    SearchIDs.Add((int)reader["id"]);
                    listbox搜尋結果.Items.Add($"{(int)reader["id"]} {reader["姓名"].ToString()} {reader["電話"].ToString()}");
                    count += 1;
                    //回去練習: 加入DataGridView
                }

                if (count == 0)
                {
                    MessageBox.Show("查無此人");
                }
                reader.Close();
                con.Close();
            } else
            {
                MessageBox.Show("請輸入, 欄位查詢關鍵字");
            }
        }

        private void radio全部_CheckedChanged(object sender, EventArgs e)
        {
            int搜尋婚姻狀態 = 0;
        }

        private void radio已婚_CheckedChanged(object sender, EventArgs e)
        {
            int搜尋婚姻狀態 = 1;
        }

        private void radio單身_CheckedChanged(object sender, EventArgs e)
        {
            int搜尋婚姻狀態 = 2;
        }

        private void listbox搜尋結果_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listbox搜尋結果.SelectedIndex >= 0)
            {
                int intSelectedID = SearchIDs[listbox搜尋結果.SelectedIndex];

                SqlConnection con = new SqlConnection(strDBConnectString);
                con.Open();
                string strSQL = "select * from persons where id = @SearchID;";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@SearchID", intSelectedID);
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read() == true)
                {
                    lblID.Text = reader["id"].ToString();
                    txt姓名.Text = reader["姓名"].ToString();
                    txt電話.Text = reader["電話"].ToString();
                    txt地址.Text = reader["地址"].ToString();
                    txtEmail.Text = reader["email"].ToString();
                    txt會員點數.Text = reader["點數"].ToString();
                    dtp生日.Value = Convert.ToDateTime(reader["生日"]);
                    chk婚姻狀態.Checked = Convert.ToBoolean(reader["婚姻狀態"]);
                }
                else
                {
                    MessageBox.Show("查無此人");
                    清空欄位();
                }
                reader.Close();
                con.Close();
            }
        }

        void 產生會員資料列表()
        {
            SqlConnection con = new SqlConnection(strDBConnectString);
            con.Open();
            //string strSQL = "select * from persons;";
            string strSQL = "select id as 會員編號, 姓名, 電話, email as 電子郵件 from persons";
            SqlCommand cmd = new SqlCommand(strSQL, con);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(reader);
                dgv會員資料列表.DataSource = dt;
            }
            reader.Close();
            con.Close();
        }

        private void dgv會員資料列表_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                string strSelectedID = dgv會員資料列表.Rows[e.RowIndex].Cells[0].Value.ToString();
                int intSelectedID = 0;
                bool isID = Int32.TryParse(strSelectedID, out intSelectedID);

                if (isID == true)
                {
                    SqlConnection con = new SqlConnection(strDBConnectString);
                    con.Open();
                    string strSQL = "select * from persons where id = @SearchID;";
                    SqlCommand cmd = new SqlCommand(strSQL, con);
                    cmd.Parameters.AddWithValue("@SearchID", intSelectedID);
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read() == true)
                    {
                        lblID.Text = reader["id"].ToString();
                        txt姓名.Text = reader["姓名"].ToString();
                        txt電話.Text = reader["電話"].ToString();
                        txt地址.Text = reader["地址"].ToString();
                        txtEmail.Text = reader["email"].ToString();
                        txt會員點數.Text = reader["點數"].ToString();
                        dtp生日.Value = Convert.ToDateTime(reader["生日"]);
                        chk婚姻狀態.Checked = Convert.ToBoolean(reader["婚姻狀態"]);
                    }
                    else
                    {
                        MessageBox.Show("查無此人");
                        清空欄位();
                    }
                    reader.Close();
                    con.Close();
                }
            }
        }
    }
}
