﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Linq_to_Class();
        }

        void Linq_to_Class()
        {
            Console.WriteLine("-----------------linq to class--------------------");
            List<Persons> listPersons = new List<Persons>()
            {
                new Persons() {姓名="David", 薪資=35000,身高=170,體重=70},
                new Persons() {姓名="Joy", 薪資=46000,身高=172,體重=75},
                new Persons() {姓名="David", 薪資=45000,身高=175,體重=89},
                new Persons() {姓名="Mary", 薪資=32000,身高=160,體重=60},
                new Persons() {姓名="Alex", 薪資=28000,身高=168,體重=50},
                new Persons() {姓名="Wang", 薪資=56000,身高=172,體重=85},
                new Persons() {姓名="John", 薪資=56000,身高=178,體重=72},
                new Persons() {姓名="Mary", 薪資=52000,身高=164,體重=52}
            };

            var result = from s in listPersons select s;
            foreach (var one in result)
            {
                Console.WriteLine($"{one.姓名} {one.薪資} {one.身高} {one.體重}");
            }
            Console.WriteLine("-------------------------------------------------");

            result = from s in listPersons where s.薪資 <= 40000 && s.薪資 >= 20000 select s; //Query Syntax
            foreach (var one in result)
            {
                Console.WriteLine($"{one.姓名} {one.薪資} {one.身高} {one.體重}");
            }
            Console.WriteLine("-------------------------------------------------");

            result = listPersons.Where (s=> s.薪資<= 40000 && s.薪資 >= 20000); //Method Syntax
            foreach (var one in result)
            {
                Console.WriteLine($"{one.姓名} {one.薪資} {one.身高} {one.體重}");
            }
            Console.WriteLine("-------------------------------------------------");

            result=from s in listPersons
                   where s.薪資>=40000
                   orderby s.身高
                   select s; //ascending
            foreach (var one in result)
            {
                Console.WriteLine($"{one.姓名} {one.薪資} {one.身高} {one.體重}");
            }
            Console.WriteLine("-------------------------------------------------");

            result = from s in listPersons
                     where s.薪資 >= 40000
                     orderby s.身高 descending
                     select s;
            foreach (var one in result)
            {
                Console.WriteLine($"{one.姓名} {one.薪資} {one.身高} {one.體重}");
            }
            Console.WriteLine("-------------------------------------------------");

            result = listPersons.Where(s => s.薪資 >= 40000).OrderBy(s => s.身高); //Method Syntax，ascending
            foreach (var one in result)
            {
                Console.WriteLine($"{one.姓名} {one.薪資} {one.身高} {one.體重}");
            }
            Console.WriteLine("-------------------------------------------------");

            result = listPersons.Where(s => s.薪資 >= 40000).OrderByDescending(s => s.身高); //Method Syntax
            foreach (var one in result)
            {
                Console.WriteLine($"{one.姓名} {one.薪資} {one.身高} {one.體重}");
            }
            Console.WriteLine("-------------------------------------------------");

            //ThenBy: Method Syntax 獨佔; Query Syntax沒有
            result = listPersons.Where(s => s.身高 >= 170).OrderBy(s => s.薪資).ThenBy(s => s.體重); //ThenBy排序的第二種條件
            result = listPersons.Where(s => s.身高 >= 170).OrderBy(s => s.薪資).ThenByDescending(s => s.體重);
            foreach (var one in result)
            {
                Console.WriteLine($"{one.姓名} {one.薪資} {one.身高} {one.體重}");
            }
            Console.WriteLine("-------------------------------------------------");

            //Group By
            var result2 = from s in listPersons group s by s.姓名;
            result2 = listPersons.GroupBy(s => s.姓名);
            foreach (var oneGroup in result2)
            {
                Console.WriteLine($"group:{oneGroup.Key}");
                foreach(var one in oneGroup)
                {
                    Console.WriteLine($"{one.姓名} {one.薪資} {one.身高} {one.體重}");
                }
            }

            //Union


        }
    }
}
