﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp7
{
    internal class Persons
    {
        public string 姓名 = "";
        public int 薪資 = 0;
        public double 身高 = 0.0;
        public double 體重= 0.0;
    }
}
