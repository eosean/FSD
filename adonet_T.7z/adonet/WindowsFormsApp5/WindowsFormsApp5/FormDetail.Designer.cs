﻿namespace WindowsFormsApp5
{
    partial class FormDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblPID = new System.Windows.Forms.Label();
            this.txt商品名稱 = new System.Windows.Forms.TextBox();
            this.txt商品價格 = new System.Windows.Forms.TextBox();
            this.txt商品描述 = new System.Windows.Forms.TextBox();
            this.pictureBox商品圖檔 = new System.Windows.Forms.PictureBox();
            this.groupBox修改 = new System.Windows.Forms.GroupBox();
            this.groupBox新增 = new System.Windows.Forms.GroupBox();
            this.btn選取商品圖片 = new System.Windows.Forms.Button();
            this.btn儲存修改 = new System.Windows.Forms.Button();
            this.btn清空欄位 = new System.Windows.Forms.Button();
            this.btn選取商品圖片2 = new System.Windows.Forms.Button();
            this.btn儲存商品 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox商品圖檔)).BeginInit();
            this.groupBox修改.SuspendLayout();
            this.groupBox新增.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(23, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 38);
            this.label1.TabIndex = 0;
            this.label1.Text = "pid";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(23, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 38);
            this.label2.TabIndex = 1;
            this.label2.Text = "商品名稱";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(23, 193);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 38);
            this.label3.TabIndex = 2;
            this.label3.Text = "商品價格";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(23, 257);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 38);
            this.label4.TabIndex = 3;
            this.label4.Text = "商品描述";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(549, 70);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 38);
            this.label5.TabIndex = 4;
            this.label5.Text = "商品圖檔";
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(263, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(336, 46);
            this.label6.TabIndex = 5;
            this.label6.Text = "商品詳細資訊";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPID
            // 
            this.lblPID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblPID.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblPID.Location = new System.Drawing.Point(171, 70);
            this.lblPID.Name = "lblPID";
            this.lblPID.Size = new System.Drawing.Size(306, 38);
            this.lblPID.TabIndex = 6;
            this.lblPID.Text = "0000000000";
            // 
            // txt商品名稱
            // 
            this.txt商品名稱.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt商品名稱.Location = new System.Drawing.Point(166, 130);
            this.txt商品名稱.Name = "txt商品名稱";
            this.txt商品名稱.Size = new System.Drawing.Size(345, 47);
            this.txt商品名稱.TabIndex = 7;
            // 
            // txt商品價格
            // 
            this.txt商品價格.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt商品價格.Location = new System.Drawing.Point(166, 190);
            this.txt商品價格.Name = "txt商品價格";
            this.txt商品價格.Size = new System.Drawing.Size(345, 47);
            this.txt商品價格.TabIndex = 8;
            // 
            // txt商品描述
            // 
            this.txt商品描述.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt商品描述.Location = new System.Drawing.Point(166, 254);
            this.txt商品描述.Multiline = true;
            this.txt商品描述.Name = "txt商品描述";
            this.txt商品描述.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt商品描述.Size = new System.Drawing.Size(345, 217);
            this.txt商品描述.TabIndex = 9;
            // 
            // pictureBox商品圖檔
            // 
            this.pictureBox商品圖檔.Location = new System.Drawing.Point(540, 111);
            this.pictureBox商品圖檔.Name = "pictureBox商品圖檔";
            this.pictureBox商品圖檔.Size = new System.Drawing.Size(363, 341);
            this.pictureBox商品圖檔.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox商品圖檔.TabIndex = 10;
            this.pictureBox商品圖檔.TabStop = false;
            // 
            // groupBox修改
            // 
            this.groupBox修改.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox修改.Controls.Add(this.btn儲存修改);
            this.groupBox修改.Controls.Add(this.btn選取商品圖片);
            this.groupBox修改.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox修改.Location = new System.Drawing.Point(56, 496);
            this.groupBox修改.Name = "groupBox修改";
            this.groupBox修改.Size = new System.Drawing.Size(393, 226);
            this.groupBox修改.TabIndex = 11;
            this.groupBox修改.TabStop = false;
            this.groupBox修改.Text = "修改商品資訊";
            // 
            // groupBox新增
            // 
            this.groupBox新增.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.groupBox新增.Controls.Add(this.btn儲存商品);
            this.groupBox新增.Controls.Add(this.btn選取商品圖片2);
            this.groupBox新增.Controls.Add(this.btn清空欄位);
            this.groupBox新增.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox新增.Location = new System.Drawing.Point(489, 496);
            this.groupBox新增.Name = "groupBox新增";
            this.groupBox新增.Size = new System.Drawing.Size(393, 226);
            this.groupBox新增.TabIndex = 12;
            this.groupBox新增.TabStop = false;
            this.groupBox新增.Text = "新增商品資訊";
            // 
            // btn選取商品圖片
            // 
            this.btn選取商品圖片.Location = new System.Drawing.Point(66, 54);
            this.btn選取商品圖片.Name = "btn選取商品圖片";
            this.btn選取商品圖片.Size = new System.Drawing.Size(256, 62);
            this.btn選取商品圖片.TabIndex = 0;
            this.btn選取商品圖片.Text = "選取商品圖片";
            this.btn選取商品圖片.UseVisualStyleBackColor = true;
            this.btn選取商品圖片.Click += new System.EventHandler(this.btn選取商品圖片_Click);
            // 
            // btn儲存修改
            // 
            this.btn儲存修改.Location = new System.Drawing.Point(66, 134);
            this.btn儲存修改.Name = "btn儲存修改";
            this.btn儲存修改.Size = new System.Drawing.Size(256, 62);
            this.btn儲存修改.TabIndex = 1;
            this.btn儲存修改.Text = "儲存修改";
            this.btn儲存修改.UseVisualStyleBackColor = true;
            this.btn儲存修改.Click += new System.EventHandler(this.btn儲存修改_Click);
            // 
            // btn清空欄位
            // 
            this.btn清空欄位.Location = new System.Drawing.Point(67, 42);
            this.btn清空欄位.Name = "btn清空欄位";
            this.btn清空欄位.Size = new System.Drawing.Size(267, 51);
            this.btn清空欄位.TabIndex = 0;
            this.btn清空欄位.Text = "清空欄位";
            this.btn清空欄位.UseVisualStyleBackColor = true;
            this.btn清空欄位.Click += new System.EventHandler(this.btn清空欄位_Click);
            // 
            // btn選取商品圖片2
            // 
            this.btn選取商品圖片2.Location = new System.Drawing.Point(67, 99);
            this.btn選取商品圖片2.Name = "btn選取商品圖片2";
            this.btn選取商品圖片2.Size = new System.Drawing.Size(267, 51);
            this.btn選取商品圖片2.TabIndex = 1;
            this.btn選取商品圖片2.Text = "選取商品圖片";
            this.btn選取商品圖片2.UseVisualStyleBackColor = true;
            this.btn選取商品圖片2.Click += new System.EventHandler(this.btn選取商品圖片_Click);
            // 
            // btn儲存商品
            // 
            this.btn儲存商品.Location = new System.Drawing.Point(67, 156);
            this.btn儲存商品.Name = "btn儲存商品";
            this.btn儲存商品.Size = new System.Drawing.Size(267, 51);
            this.btn儲存商品.TabIndex = 2;
            this.btn儲存商品.Text = "儲存商品";
            this.btn儲存商品.UseVisualStyleBackColor = true;
            this.btn儲存商品.Click += new System.EventHandler(this.btn儲存商品_Click);
            // 
            // FormDetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(928, 734);
            this.Controls.Add(this.groupBox新增);
            this.Controls.Add(this.groupBox修改);
            this.Controls.Add(this.pictureBox商品圖檔);
            this.Controls.Add(this.txt商品描述);
            this.Controls.Add(this.txt商品價格);
            this.Controls.Add(this.txt商品名稱);
            this.Controls.Add(this.lblPID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormDetail";
            this.Text = "商品詳細資訊";
            this.Load += new System.EventHandler(this.FormDetail_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox商品圖檔)).EndInit();
            this.groupBox修改.ResumeLayout(false);
            this.groupBox新增.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblPID;
        private System.Windows.Forms.TextBox txt商品名稱;
        private System.Windows.Forms.TextBox txt商品價格;
        private System.Windows.Forms.TextBox txt商品描述;
        private System.Windows.Forms.PictureBox pictureBox商品圖檔;
        private System.Windows.Forms.GroupBox groupBox修改;
        private System.Windows.Forms.Button btn儲存修改;
        private System.Windows.Forms.Button btn選取商品圖片;
        private System.Windows.Forms.GroupBox groupBox新增;
        private System.Windows.Forms.Button btn儲存商品;
        private System.Windows.Forms.Button btn選取商品圖片2;
        private System.Windows.Forms.Button btn清空欄位;
    }
}