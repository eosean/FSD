﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;


namespace WebApplication1.Models
{
    [ModelMetadataTypeAttribute(typeof(TCustomerMetadata))]
    public partial class TCustomer
    {
    }

    [ModelMetadataTypeAttribute(typeof(TProductMetadata))]
    public partial class TProduct
    {

    }
    [ModelMetadataTypeAttribute(typeof(TShoppingCartMetadata))]
    public partial class TShoppingCart
    {

    }
}
