﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{  
        public class TCustomerMetadata
        {

            public int FId { get; set; }

            [Display(Name = "姓名")]
            public string FName { get; set; }

            [Display(Name = "電話")]
            public string FPhone { get; set; }
      
        [Display(Name = "電子郵件")]
        public string FEmail { get; set; }
            public string FAddress { get; set; }
            public string FPassword { get; set; }
        }

    public  class TProductMetadata
    {
        public int FId { get; set; }

        public string FName { get; set; }
        public int? FQty { get; set; }
        public decimal? FCost { get; set; }
        public decimal? FPrice { get; set; }
        public string FImagePath { get; set; }
    }

    public class TShoppingCartMetadata
    {
        public int FId { get; set; }

        [Display(Name ="日期")]
        public string FDate { get; set; }
        public int? FCustomerId { get; set; }
        public int? FProductId { get; set; }
        public int? FCount { get; set; }
        public decimal? FPrice { get; set; }
    }

}
